const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;
const IMAGES_DIR = path.join(__dirname, 'Images');

// Respects X-Forwarded-Proto from a reverse proxy (Render, Heroku, nginx, etc.)
// so req.protocol below reports "https" correctly in production instead of
// always "http".
app.set('trust proxy', 1);

app.use(cors());

if (!fs.existsSync(IMAGES_DIR)) {
  console.warn(
    `\n⚠️  No "Images" folder found at ${IMAGES_DIR}.\n` +
    `   Create it and add your product photos there — filenames must match\n` +
    `   exactly what's listed in each product's "colors[].images" array below.\n`
  );
}

// Serve static files from the Images folder
app.use('/Images', express.static(IMAGES_DIR));

// Product data
const products = [
  {
    id: 1,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "A timeless essential, the Signature Tee features a minimalist design with premium cotton fabric for all-day comfort. Perfect for layering or wearing solo, it’s a staple for any modern wardrobe",
    category: "T-Shirt/Tops",
    colors:[
     { name: "White", hex: "#ffffff",  images: ["WhatsApp Image 2025-05-08 at 11.16.08 (1).jpeg"]}, 
     { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (4).jpeg"]}

    ]
  },
  {
    id: 2,
    title: "Magnum Opus Lucid Silence Tee",
    price: 809.95,
    description: "Crafted for those who appreciate subtlety, the Lucid Silence Tee blends soft, breathable fabric with a sleek silhouette. Its understated design speaks volumes in quiet confidence",
    category: "T-Shirt/Tops",
    colors:[
     { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (1).jpeg"] }
    ]
  },
  {
    id: 4,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "This Signature Tee offers a clean, structured fit with a soft touch. Designed for versatility, it transitions effortlessly from casual to elevated streetwear.",
    category: "T-Shirt/Tops",
    colors:[
     { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (3).jpeg"]}
    ]
  },
  {
    id: 5,
    title: "Magnum Opus Signature Tee",
    price: 709.95,
    description: "Elevate your basics with this refined Signature Tee. Featuring a slightly heavier cotton blend, it offers durability without compromising on comfort.",
    category: "T-Shirt/Tops",
    colors:[
     { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (4).jpeg"]}
    ]
  },
  {
    id: 6,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "Crafted from premium cotton, this tee offers a soft touch and a structured fit. Ideal for layering or wearing solo, it's a versatile staple for any wardrobe.",
    category: "T-Shirt/Tops",
    colors:[
    { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (5).jpeg"]} 
    ]
  },
  {
    id: 7,
    title: "Magnum Opus Signature Tee",
    price: 809.95,
    description: "A bold expression of comfort and style, this hoodie features a relaxed fit, brushed fleece interior, and signature branding. Ideal for layering or lounging",
    category: "Hoodie",
    colors:[
    { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-08-06 at 21.11.38 (1).jpeg"]} 
  ]
  },
  {
    id: 8,
    title: "Magnum Opus Signature Tee",
    price: 709.95,
    description: "This Signature Tee offers a clean, structured fit with a soft touch. Designed for versatility, it transitions effortlessly from casual to elevated streetwear.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (7)Front.jpeg","WhatsApp Image 2025-05-08 at 11.16.09 (7)Back.jpeg" ] },
      { name: "White", hex: "#ffffff", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (8)Front.jpeg","WhatsApp Image 2025-05-08 at 11.16.09 (8)Back.jpeg"]} 

    ]
  },
  {
    id: 9,
    title: "Magnum Opus Signature Tee",
    price: 709.95,
    description: "This Signature Tee offers a clean, structured fit with a soft touch. Designed for versatility, it transitions effortlessly from casual to elevated streetwear.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (8)Front.jpeg", "WhatsApp Image 2025-05-08 at 11.16.09 (8)Back.jpeg" ]}
    ]
  },
  {
    id: 10,
    title: "Magnum Opus Signature Tee",
    price: 509.95,
    description: "Designed for movement and comfort, these Signature Shorts feature a relaxed fit, elastic waistband, and breathable fabric—ideal for everyday wear or active days.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (9).jpeg"]}
    ]
  },
  {
    id: 11,
    title: "Magnum Opus Signature Tee",
    price: 509.95,
    description: "These shorts are designed for comfort and mobility, featuring a relaxed fit, breathable fabric, and an elastic waistband for everyday ease.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (10).jpeg"]}
    ]
  } ,
  {
    id: 12,
    title: "Magnum Opus Signature Tee",
    price: 509.95,
    description: "Designed for movement and comfort, these Signature Shorts feature a relaxed fit, elastic waistband, and breathable fabric—ideal for everyday wear or active days.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000", images: ["WhatsApp Image 2025-05-08 at 11.16.09 (11).jpeg"]}
    ]
  },
  {
    id: 13,
    title: "Magnum Opus Signature Tee",
    price: 509.95,
    description: "These shorts are designed for comfort and mobility, featuring a relaxed fit, breathable fabric, and an elastic waistband for everyday ease.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09 (12).jpeg"]}
    ]
   } ,
  {
    id: 14,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "This Signature Tee offers a clean, structured fit with a soft touch. Designed for versatility, it transitions effortlessly from casual to elevated streetwear.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.09.jpeg"]}
    ]
  },
  {
    id: 15,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "Designed for movement and comfort, these Signature Shorts feature a relaxed fit, elastic waistband, and breathable fabric—ideal for everyday wear or active days.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (1).jpeg"]}
    ]
  },
  {
    id: 16,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "Crafted from premium cotton, this tee offers a soft touch and a structured fit. Ideal for layering or wearing solo, it's a versatile staple for any wardrobe.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (2).jpeg"]}
    ]
  },
  {
    id: 17,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "Crafted from premium cotton, this tee offers a soft touch and a structured fit. Ideal for layering or wearing solo, it's a versatile staple for any wardrobe.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (3).jpeg"]},
      { name:"White", hex: "#ffffff", images: ["WhatsApp Image 2025-05-08 at 11.16.10 (4).jpeg"]}
    ]
  },
  {
    id: 18,
    title: "Magnum Opus Signature Tee",
    price: 609.95,
    description: "Crafted from premium cotton, this tee offers a soft touch and a structured fit. Ideal for layering or wearing solo, it's a versatile staple for any wardrobe.",
    category: "T-Shirt/Tops",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (4).jpeg"]}
    ]
  },
  {
    id: 19,
    title: "Magnum Opus Signature Tee",
    price: 509.95,
    description: "These shorts are designed for comfort and mobility, featuring a relaxed fit, breathable fabric, and an elastic waistband for everyday ease.",
    category: "Shorts",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (5).jpeg"]}
    ]
  },
  {
    id: 20,
    title: "Magnum Opus Signature Tee",
    price: 809.95,
    description: "This hoodie combines cozy fleece lining with a relaxed silhouette, making it perfect for layering or lounging in style.",
    category: "Hoodie",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (6)Back.jpeg"]},
      { name: "White", hex: "#ffffff",images: ["WhatsApp Image 2025-05-08 at 11.16.10 (6)Front.jpeg"]}
    ]
  },
  {
    id: 21,
    title: "Magnum Opus Hoodie",
    price: 809.95,
    description: "This hoodie combines cozy fleece lining with a relaxed silhouette, making it perfect for layering or lounging in style.",
    category: "Hoodie",
    colors:[
      { name: "Black", hex: "#000000",images: ["WhatsApp Image 2025-08-06 at 21.10.30 (2).jpeg"]}
    ]
  },
  {
    id: 22,
    title: "Magnum Opus Hoodie",
    price: 809.95,
    description: "This hoodie combines cozy fleece lining with a relaxed silhouette, making it perfect for layering or lounging in style.",
    category: "Hoodie",
    colors:[
      { name: "Black", hex: "#000000",images: ["Untitled (1).png"]}
    ]
  },
  {
    id: 23,
    title: "Magnum Opus Cap",
    price: 809.95,
    description: "This cap combines cozy fleece lining with a relaxed silhouette, making it perfect for layering or lounging in style.",
    category: "Cap",
    colors:[
      { name: "Black", hex: "#000000",images: ["Untitled (2).png"]}
    ]
  }
];

// Turns relative image filenames into absolute URLs the frontend can load
// directly from an <img> tag, regardless of what host the API is running on.
const withAbsoluteImageUrls = (host) => (product) => ({
  ...product,
  colors: (product.colors || []).map((color) => ({
    ...color,
    images: Array.isArray(color.images)
      ? color.images.map((img) => `${host}/Images/${encodeURIComponent(img)}`)
      : [],
  })),
});

app.get('/', (_req, res) => {
  res.json({ status: 'ok', message: 'Magnum Opus backend is running', products: products.length });
});

app.get('/api/products', (req, res) => {
  const host = `${req.protocol}://${req.get('host')}`;
  res.json(products.map(withAbsoluteImageUrls(host)));
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  const host = `${req.protocol}://${req.get('host')}`;
  res.json(withAbsoluteImageUrls(host)(product));
});

// 404 for anything else under /api
app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Basic error handler so a thrown error doesn't crash the process silently
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Backend API running at http://localhost:${PORT}`);
});
