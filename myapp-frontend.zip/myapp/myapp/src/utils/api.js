// src/utils/api.js
//
// Single data-access layer for the storefront. Backed by the real Express
// API in `src/services/backend.js` — see that file to change the API URL
// or how products are cached.

import { getProducts, getProductById } from '../services/backend';

// react-query fetcher for a page of products: queryKey = ['products', { search, category, page, limit }]
export const fetchProducts = async ({ queryKey, pageParam }) => {
  const [, params = {}] = queryKey;
  const page = pageParam ?? params.page ?? 1;
  return getProducts({ ...params, page });
};

// react-query fetcher for a single product: queryKey = ['product', id]
export const fetchProduct = async ({ queryKey }) => {
  const [, id] = queryKey;
  return getProductById(id);
};

export const fetchAllProducts = async () => (await getProducts({ limit: 999 })).items;
