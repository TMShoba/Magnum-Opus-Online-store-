import React from 'react';
import { useNavigate } from 'react-router-dom';
import './ErrorFallback.css';

const ErrorFallback = ({ error, resetErrorBoundary }) => {
  const navigate = useNavigate();

  const handleReset = () => {
    resetErrorBoundary();
    navigate('/');
  };

  return (
    <div className="error-fallback">
      <div className="error-content">
        <h2>Something went wrong</h2>
        <p className="error-message">{error.message}</p>
        <div className="error-actions">
          <button className="btn btn-solid" onClick={handleReset}>Go to Home</button>
          <button className="btn" onClick={resetErrorBoundary}>Try Again</button>
        </div>
      </div>
    </div>
  );
};

export default ErrorFallback;
