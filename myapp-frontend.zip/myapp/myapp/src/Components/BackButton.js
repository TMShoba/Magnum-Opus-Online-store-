import React from 'react';
import { useNavigate } from 'react-router-dom';
import './BackButton.css';

const BackButton = ({ className = '', children = '← Back' }) => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1); // Go back to previous page in history
  };

  return (
    <button 
      className={`back-button ${className}`} 
      onClick={handleBack}
    >
      {children}
    </button>
  );
};

export default BackButton;
