import React, { useContext, useState, useCallback, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ThemeContext } from '../Context/ThemeContext';
import { useCart } from '../Context/CartContext';
import { useAuth } from '../Context/AuthContext';
import { FaUser, FaSignInAlt, FaSignOutAlt, FaShoppingCart, FaSun, FaMoon, FaBars, FaTimes, FaHeart } from 'react-icons/fa';
import './NavBar.css';

const Navbar = ({ onCartOpen }) => {
  const { darkMode, toggleTheme } = useContext(ThemeContext);
  const { itemCount } = useCart();
  const { isAuthenticated, user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  // Close mobile menu and dropdown when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setDropdownOpen(null);
  }, [location]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownOpen && !event.target.closest('.account-dropdown')) {
        setDropdownOpen(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [dropdownOpen]);

  const handleLogout = useCallback(() => {
    logout();
    navigate('/');
    setDropdownOpen(null);
  }, [logout, navigate]);

  const toggleMobileMenu = useCallback(() => {
    setIsMobileMenuOpen(prev => !prev);
  }, []);

  const toggleThemeWithFeedback = useCallback(() => {
    toggleTheme();
  }, [toggleTheme]);

  return (
    <nav className={`navbar ${darkMode ? 'dark' : 'light'}`}>
      <div className="nav-container">
        {/* Mobile Menu Button */}
        <button 
          className="mobile-menu-btn" 
          onClick={toggleMobileMenu}
          aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={isMobileMenuOpen}
        >
          {isMobileMenuOpen ? <FaTimes /> : <FaBars />}
        </button>

        {/* Logo */}
        <Link to="/" className="logo-link">
          <img 
            src="/images/logo.jpeg" 
            alt="Company Logo" 
            className="logo-img"
            width="120"
            height="40"
          />
        </Link>

        {/* Desktop Navigation */}
        <div className={`nav-links ${isMobileMenuOpen ? 'open' : ''}`}>
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/products" className="nav-link">Shop</Link>
          <Link to="/about" className="nav-link">About</Link>
        </div>

        <div className="nav-actions">
          {/* Theme Toggle */}
          <button 
            className="theme-toggle" 
            onClick={toggleThemeWithFeedback}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {darkMode ? <FaSun /> : <FaMoon />}
          </button>

          {/* Cart */}
          <button 
            className="icon-button" 
            onClick={onCartOpen}
            aria-label={`View cart (${itemCount} items)`}
          >
            <FaShoppingCart className="cart-icon" />
            {itemCount > 0 && (
              <span className="cart-count">
                {itemCount > 9 ? '9+' : itemCount}
              </span>
            )}
          </button>

          {/* Wishlist */}
          <Link to="/wishlist" className="icon-button" aria-label="View wishlist">
            <FaHeart />
          </Link>

          {/* Account Dropdown */}
          <div 
            className={`account-dropdown ${dropdownOpen === 'account' ? 'open' : ''}`}
            onMouseEnter={() => setDropdownOpen('account')}
            onMouseLeave={() => setDropdownOpen(null)}
          >
            <button 
              className="account-btn"
              onClick={() => setDropdownOpen(prev => prev === 'account' ? null : 'account')}
              aria-expanded={dropdownOpen === 'account'}
              aria-haspopup="true"
            >
              <FaUser className="user-icon" />
              <span className="account-text">
                {isAuthenticated ? (user?.name || 'Account') : 'Account'}
              </span>
            </button>
            
            <div className="dropdown-menu">
              {isAuthenticated ? (
                <>
                  <button onClick={handleLogout} className="dropdown-item">
                    <FaSignOutAlt /> Logout
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="dropdown-item">
                    <FaSignInAlt /> Login
                  </Link>
                  <Link to="/signup" className="dropdown-item">
                    <FaUser /> Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
