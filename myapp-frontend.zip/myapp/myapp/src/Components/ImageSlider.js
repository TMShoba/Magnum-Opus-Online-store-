import React, { useState } from 'react';
import { useSwipeable } from 'react-swipeable';
import ImageZoomModal from './ImageZoomModal';
import './ImageSlider.css';

const ImageSlider = ({ images }) => {
  const [index, setIndex] = useState(0);
  const [isZoomOpen, setIsZoomOpen] = useState(false);

  const next = () => setIndex((index + 1) % images.length);
  const prev = () => setIndex((index - 1 + images.length) % images.length);

  const handlers = useSwipeable({
    onSwipedLeft: next,
    onSwipedRight: prev,
    trackMouse: true, // allows swiping with mouse
  });

  const handleImageClick = () => {
    setIsZoomOpen(true);
  };

  return (
    <div className="image-slider" {...handlers}>
      <button className="nav-btn" onClick={prev}>‹</button>
      <img 
        src={images[index]} 
        alt={`Product view ${index + 1}`}
        className="zoomable-image"
        onClick={handleImageClick}
      />
      <button className="nav-btn" onClick={next}>›</button>
      
      <ImageZoomModal
        src={images[index]}
        alt={`Product view ${index + 1}`}
        isOpen={isZoomOpen}
        onClose={() => setIsZoomOpen(false)}
      />
    </div>
  );
};

export default ImageSlider;
