import React from 'react';
import { useCart } from '../Context/CartContext';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom'; // ✅ import navigation
import './CartSideBar.css';

const CartSidebar = ({ isOpen, onClose }) => {
  const { cartItems, removeFromCart } = useCart();
  const navigate = useNavigate(); // ✅ use navigate

  const handleCheckout = () => {
    onClose(); // Close the sidebar
    navigate('/checkout'); // Navigate to checkout
  };

  return (
    <>
      {isOpen && <div className="cart-overlay" onClick={onClose}></div>}

      <motion.div
        className="cart-sidebar"
        initial={{ x: '100%' }}
        animate={{ x: isOpen ? 0 : '100%' }}
        exit={{ x: '100%' }}
        transition={{ type: 'tween', duration: 0.4 }}
      >
        <div className="cart-header">
          <h2>Your Cart</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        <div className="cart-items">
          {cartItems.length === 0 ? (
            <p className="empty-cart">Your cart is empty.</p>
          ) : (
            cartItems.map(item => (
              <div className="cart-item" key={item.id}>
                <img src={item.image} alt={item.title} />
                <div>
                  <h4>{item.title}</h4>
                  <p>R{item.price}</p>
                  <button onClick={() => removeFromCart(item.id)}>Remove</button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* ✅ Proceed to Checkout Button */}
        {cartItems.length > 0 && (
          <div className="cart-footer">
            <button className="luxury-button" onClick={handleCheckout}>
              Proceed to Checkout
            </button>
          </div>
        )}
      </motion.div>
    </>
  );
};

export default CartSidebar;
