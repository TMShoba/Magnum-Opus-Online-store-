import React from 'react';
import './ImageZoomModal.css';

const ImageZoomModal = ({ src, alt, isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="zoom-modal-overlay" onClick={onClose}>
      <div className="zoom-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="zoom-modal-close" onClick={onClose}>
          ×
        </button>
        <img src={src} alt={alt} className="zoom-modal-image" />
      </div>
    </div>
  );
};

export default ImageZoomModal;
