import React, { useState } from 'react';
import { useSwipeable } from 'react-swipeable';
import { useNavigate } from 'react-router-dom';
import './ProductSlider.css';

const ProductSlider = ({ products, onAddToWishlist }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const navigate = useNavigate();
  const itemsPerView = 3; // Show 3 items at once

  const next = () => {
    setCurrentIndex((prev) => 
      prev + itemsPerView >= products.length ? 0 : prev + itemsPerView
    );
  };

  const prev = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? Math.max(0, products.length - itemsPerView) : prev - itemsPerView
    );
  };

  const handlers = useSwipeable({
    onSwipedLeft: next,
    onSwipedRight: prev,
    trackMouse: true,
  });

  return (
    <div className="product-slider" {...handlers}>
      <div className="slider-container">
        <div 
          className="slider-track"
          style={{ transform: `translateX(-${currentIndex * 320}px)` }}
        >
          {products.map((product) => {
            return (
              <div key={product.id} className="slider-item">
                <img
                  src={product.image}
                  alt={product.title}
                  onClick={() => navigate(`/products/${product.id}`)}
                />
                <h4>{product.title}</h4>
                <p>R{product.price}</p>
                <button 
                  className="add-to-wishlist-btn"
                  onClick={() => onAddToWishlist(product)}
                >
                  Add to Wishlist
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProductSlider;

