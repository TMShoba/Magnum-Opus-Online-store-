// src/Pages/Home.js
import React, { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Home.css';
import { useCart } from '../Context/CartContext';
import { useAllProducts } from '../hooks/useAllProducts';
import Collections from './Collections';
import LoadingSpinner from '../Components/common/LoadingSpinner';

const Home = () => {
  const { data: allProducts = [], isLoading, isError } = useAllProducts();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  // One piece per category, so the homepage represents the full range.
  const featured = useMemo(() => {
    const seen = new Set();
    const picks = [];
    for (const product of allProducts) {
      if (!seen.has(product.category)) {
        seen.add(product.category);
        picks.push(product);
      }
    }
    return picks;
  }, [allProducts]);

  const handleBuyNow = (item) => {
    addToCart({ ...item, quantity: 1 });
    navigate('/checkout');
  };

  return (
    <div className="home">
      <div className="hero-video-container">
        <video autoPlay muted loop playsInline className="hero-video">
          <source src="/videos/hero-video.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>

        <div className="video-overlay">
          <h1>Magnum Opus</h1>
          <p>Considered pieces, made to last.</p>
          <Link to="/products">
            <button className="video-cta-button">Shop the collection</button>
          </Link>
        </div>
      </div>

      <section className="shop-by-category">
        <h2>Shop by Category</h2>
        <Collections />
      </section>

      <section className="featured-products">
        <h2>Featured</h2>
        {isLoading ? (
          <LoadingSpinner text="Loading products..." />
        ) : isError ? (
          <p>Couldn't load products. Is the backend running?</p>
        ) : featured.length === 0 ? (
          <p>No products available.</p>
        ) : (
          <div className="product-grid">
            {featured.map((item) => (
              <div key={item.id} className="product-card" onClick={() => navigate(`/products/${item.id}`)}>
                <div className="product-card-image">
                  <img src={item.image} alt={item.title} />
                </div>
                <h3>{item.title}</h3>
                <p>R{item.price}</p>
                <div className="product-actions">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(item);
                    }}
                  >
                    Add to Cart
                  </button>
                  <button
                    className="secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleBuyNow(item);
                    }}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default Home;
