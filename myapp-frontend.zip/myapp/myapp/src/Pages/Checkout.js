import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import './Checkout.css';

// IMPORTANT: only ever put a Paystack *public* key (starts with "pk_") in
// frontend code. The previous version of this file shipped a *secret* key
// (starts with "sk_") in the bundle — anyone viewing the page source could
// have used it to make charges or refunds on the account. Secret keys must
// stay on a server; the browser should never see them.
const PAYSTACK_PUBLIC_KEY = process.env.REACT_APP_PAYSTACK_PUBLIC_KEY || '';

const Checkout = () => {
  const { cartItems, clearCart } = useCart();
  const navigate = useNavigate();
  const [placing, setPlacing] = useState(false);

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const payWithPaystack = () => {
    if (!PAYSTACK_PUBLIC_KEY) {
      // No backend is wired up in this project yet, so payment can't be
      // taken for real. Simulate a successful order instead of failing
      // silently or exposing a fake key.
      setPlacing(true);
      setTimeout(() => {
        setPlacing(false);
        clearCart();
        navigate('/');
      }, 900);
      return;
    }

    if (window.PaystackPop) {
      const handler = window.PaystackPop.setup({
        key: PAYSTACK_PUBLIC_KEY,
        email: 'customer@example.com',
        amount: Math.round(total * 100),
        currency: 'ZAR',
        ref: `order_${Date.now()}`,
        callback: () => {
          clearCart();
          navigate('/');
        },
        onClose: () => {},
      });
      handler.openIframe();
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="checkout-page checkout-empty">
        <h2>Your cart is empty</h2>
        <p>Add something to your cart before checking out.</p>
        <Link to="/products" className="back-to-cart-btn">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <h2>Checkout</h2>
      <div className="cart-items">
        {cartItems.map((item) => (
          <div className="cart-item" key={item.id}>
            <img src={item.image} alt={item.title} className="cart-item-img" />
            <div className="cart-item-details">
              <h3>{item.title}</h3>
              <p>R{item.price}</p>
              <p>Quantity: {item.quantity}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="checkout-summary">
        <p>Total: R{total.toFixed(2)}</p>
        <button onClick={payWithPaystack} className="checkout-btn" disabled={placing}>
          {placing ? 'Placing order…' : 'Proceed to Payment'}
        </button>
      </div>

      <button onClick={() => navigate('/cart')} className="back-to-cart-btn">
        Back to Cart
      </button>
    </div>
  );
};

export default Checkout;
