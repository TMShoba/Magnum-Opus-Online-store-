// src/Pages/Collections.js
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import './Collections.css';
import { useAllProducts } from '../hooks/useAllProducts';

const Collections = () => {
  const { data: allProducts = [], isLoading } = useAllProducts();

  const collections = useMemo(() => {
    const byCategory = new Map();
    for (const product of allProducts) {
      if (!byCategory.has(product.category)) {
        byCategory.set(product.category, product.image);
      }
    }
    return [...byCategory.entries()].map(([name, image]) => ({ name, image }));
  }, [allProducts]);

  if (isLoading) return null;

  return (
    <div className="collections-grid">
      {collections.map((col) => (
        <Link to={`/collections/${encodeURIComponent(col.name)}`} key={col.name} className="collection-card">
          <img src={col.image} alt={col.name} />
          <h3>{col.name}</h3>
        </Link>
      ))}
    </div>
  );
};

export default Collections;
