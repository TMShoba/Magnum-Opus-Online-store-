// src/Pages/CollectionPage.js
import React, { useMemo, useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './CollectionPage.css';
import { useCart } from '../Context/CartContext';
import { useWishlist } from '../Context/WishlistContext';
import { useAllProducts } from '../hooks/useAllProducts';
import LoadingSpinner from '../Components/common/LoadingSpinner';

const CollectionPage = () => {
  const { id } = useParams();
  const decodedId = id ? decodeURIComponent(id) : 'All';
  const [selectedCategory, setSelectedCategory] = useState(decodedId);
  const { data: allProducts = [], isLoading } = useAllProducts();
  const { addToCart } = useCart();
  const { addToWishlist } = useWishlist();

  // Keep the tab selection in sync if the user navigates here via a
  // different category link while already on this page.
  useEffect(() => {
    setSelectedCategory(decodedId);
  }, [decodedId]);

  const categories = useMemo(() => [...new Set(allProducts.map((p) => p.category))], [allProducts]);

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'All') return allProducts;
    return allProducts.filter((p) => p.category.toLowerCase() === selectedCategory.toLowerCase());
  }, [allProducts, selectedCategory]);

  if (isLoading) return <LoadingSpinner fullPage text="Loading collection..." />;

  return (
    <div className="collection-page">
      <h2>Collections</h2>

      <div className="category-tabs">
        {['All', ...categories].map((cat) => (
          <button
            key={cat}
            className={`tab-button ${selectedCategory === cat ? 'active' : ''}`}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {filteredProducts.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <div className="product-grid">
          {filteredProducts.map((item) => (
            <div key={item.id} className="product-card">
              <Link to={`/products/${item.id}`}>
                <img src={item.image} alt={item.title} />
              </Link>
              <h4>{item.title}</h4>
              <p>R {item.price.toFixed(2)}</p>
              <div className="product-actions">
                <button onClick={() => addToCart({ ...item, quantity: 1 })}>Add to Cart</button>
                <button onClick={() => addToWishlist(item)}>Wishlist</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CollectionPage;
