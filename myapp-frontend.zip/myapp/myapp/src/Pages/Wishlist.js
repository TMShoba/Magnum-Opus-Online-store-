import React from 'react';
import { useWishlist } from '../Context/WishlistContext';
import { useCart } from '../Context/CartContext';
import { useNavigate } from 'react-router-dom';
import ProductSlider from '../Components/ProductSlider';
import { useAllProducts } from '../hooks/useAllProducts';
import LoadingSpinner from '../Components/common/LoadingSpinner';
import './Wishlist.css';

const Wishlist = () => {
  const { wishlistItems, addToWishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { data: allProducts = [], isLoading } = useAllProducts();
  const navigate = useNavigate();

  if (!wishlistItems || wishlistItems.length === 0) {
    return (
      <div className="wishlist-page">
        <h1 className="wishlist-title">Your Wishlist</h1>
        <p className="empty-wishlist-msg">Your wishlist is empty.</p>

        <div className="suggested-products">
          <h3>You might like these</h3>
          {isLoading ? (
            <LoadingSpinner text="Loading suggestions..." />
          ) : (
            <ProductSlider products={allProducts.slice(0, 9)} onAddToWishlist={addToWishlist} />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="wishlist-page">
      <h1 className="wishlist-title">Your Wishlist</h1>

      <div className="wishlist-items">
        {wishlistItems.map((item) => (
          <div key={item.id} className="wishlist-card">
            <img
              src={item.image}
              alt={item.title}
              className="wishlist-img"
              onClick={() => navigate(`/products/${item.id}`)}
            />
            <h3>{item.title}</h3>
            <p>R{item.price}</p>
            <div className="wishlist-buttons">
              <button className="wishlist-btn add-btn" onClick={() => addToCart({ ...item, quantity: 1 })}>
                Add to Cart
              </button>
              <button className="wishlist-btn remove-btn" onClick={() => removeFromWishlist(item.id)}>
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Wishlist;
