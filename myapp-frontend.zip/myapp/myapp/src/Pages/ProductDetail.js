import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchProduct } from '../utils/api';
import ImageSlider from '../Components/ImageSlider';
import BackButton from '../Components/BackButton';
import LoadingSpinner from '../Components/common/LoadingSpinner';
import { useCart } from '../Context/CartContext';
import './ProductDetail.css';

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [item, setItem] = useState(null);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setSelectedColorIndex(0);
    fetchProduct({ queryKey: ['product', id] }).then((product) => {
      if (!cancelled) {
        setItem(product);
        setLoading(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (loading) return <LoadingSpinner fullPage text="Loading product..." />;
  if (!item) return <p className="detail-status">Product not found.</p>;

  const selectedColor = item.colors?.[selectedColorIndex];

  const handleAddToCart = () => {
    addToCart({
      id: item.id,
      title: item.title,
      price: item.price,
      quantity: 1,
      image: selectedColor?.images?.[0] || item.image,
    });
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  return (
    <div className="item-detail">
      <BackButton className="elegant" />
      <div className="item-images">
        {selectedColor?.images?.length > 0 ? (
          <ImageSlider images={selectedColor.images} />
        ) : (
          <img src={item.image} alt={item.title} className="item-img" />
        )}
      </div>
      <div className="item-info">
        <p className="item-category">{item.category}</p>
        <h2>{item.title}</h2>
        <p className="description">{item.description}</p>
        <p className="price">R{item.price}</p>

        {item.colors?.length > 0 && (
          <div className="color-options">
            {item.colors.map((color, index) => (
              <button
                key={color.name}
                className={`color-button ${index === selectedColorIndex ? 'selected' : ''}`}
                style={{ backgroundColor: color.hex }}
                onClick={() => setSelectedColorIndex(index)}
                title={color.name}
              />
            ))}
          </div>
        )}

        <div className="buttons">
          <button className="buy-button" onClick={handleAddToCart}>Add to Cart</button>
          <button className="buy-button buy-now" onClick={handleBuyNow}>Buy Now</button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
