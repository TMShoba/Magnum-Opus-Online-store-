// src/Pages/About.js
import React from 'react';
import './About.css';

const About = () => {
  return (
    <div
      className="about-container"
      style={{ backgroundImage: `linear-gradient(rgba(27, 24, 18, 0.55), rgba(27, 24, 18, 0.55)), url(${process.env.PUBLIC_URL}/images/About-bg.jpg)` }}
    >
      <div className="about-content">
        <p className="about-eyebrow">Our Story</p>
        <h1 className="about-heading">Magnum Opus</h1>
        <p className="about-tagline">Considered pieces, made to last.</p>
        <p className="about-description">
          Magnum Opus was founded on a simple belief: that clothing should be built with the same
          care it takes to build anything worth keeping. We work with small mills and long-standing
          workshops, choosing natural fibres and finishes that improve with age rather than wear out.
        </p>
        <p className="about-description">
          Every piece is designed to be worn for years, not seasons — a quiet wardrobe of things
          you reach for again and again.
        </p>
        <p className="about-quote">"Luxury is not a label. It's a standard."</p>
      </div>
    </div>
  );
};

export default About;
