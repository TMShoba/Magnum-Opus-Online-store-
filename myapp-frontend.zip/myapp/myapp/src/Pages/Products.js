import React, { useState, useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useInfiniteQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { FaHeart, FaShoppingCart, FaSearch, FaSpinner } from 'react-icons/fa';
import { useInfiniteScroll } from '../hooks/useInfiniteScroll';
import { fetchProducts } from '../utils/api';
import { useCart } from '../Context/CartContext';
import { useWishlist } from '../Context/WishlistContext';
import { toast } from 'react-toastify';
import { useAllProducts } from '../hooks/useAllProducts';
import './Products.css';

const PAGE_SIZE = 8;

const Products = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('All');
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { data: allProducts = [] } = useAllProducts();
  const categories = useMemo(() => [...new Set(allProducts.map((p) => p.category))], [allProducts]);

  const {
    data,
    isLoading,
    isError,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
  } = useInfiniteQuery({
    queryKey: ['products', { search: searchQuery, category, limit: PAGE_SIZE }],
    queryFn: fetchProducts,
    getNextPageParam: (lastPage, allPages) => (lastPage.hasMore ? allPages.length + 1 : undefined),
  });

  const loadMore = useCallback(async () => {
    if (hasNextPage) await fetchNextPage();
    return Boolean(hasNextPage);
  }, [fetchNextPage, hasNextPage]);

  const { lastElementRef } = useInfiniteScroll(loadMore, { threshold: 0.5 });

  const products = useMemo(() => data?.pages.flatMap((page) => page.items) || [], [data]);

  const handleAddToCart = (product) => {
    addToCart(product);
    toast.success(`${product.title} added to cart!`);
  };

  const handleWishlistToggle = (product) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
      toast.info(`${product.title} removed from wishlist`);
    } else {
      addToWishlist(product);
      toast.success(`${product.title} added to wishlist!`);
    }
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <FaSpinner className="spinner" />
        <p>Loading products...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="error-container">
        <p>Something went wrong loading products. Please try again.</p>
      </div>
    );
  }

  return (
    <div className="products-container">
      <div className="products-header">
        <h1>Our Products</h1>
        <form onSubmit={(e) => e.preventDefault()} className="search-form">
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button type="submit" aria-label="Search">
            <FaSearch />
          </button>
        </form>
      </div>

      <div className="category-tabs">
        {['All', ...categories].map((cat) => (
          <button
            key={cat}
            className={`tab-button ${category === cat ? 'active' : ''}`}
            onClick={() => setCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {products.length === 0 ? (
        <p className="empty-state">No products match your search.</p>
      ) : (
        <AnimatePresence>
          <div className="products-grid">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                ref={index === products.length - 1 ? lastElementRef : null}
                className="product-card"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Link to={`/products/${product.id}`} className="product-link">
                  <div className="product-image">
                    <img src={product.image} alt={product.title} loading="lazy" />
                  </div>
                  <div className="product-info">
                    <h3>{product.title}</h3>
                    <p className="price">R{product.price.toFixed(2)}</p>
                  </div>
                </Link>
                <div className="product-actions">
                  <button
                    className={`wishlist-btn ${isInWishlist(product.id) ? 'active' : ''}`}
                    onClick={() => handleWishlistToggle(product)}
                    aria-label={isInWishlist(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                  >
                    <FaHeart />
                  </button>
                  <button className="add-to-cart" onClick={() => handleAddToCart(product)}>
                    <FaShoppingCart /> Add to Cart
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </AnimatePresence>
      )}

      {isFetchingNextPage && (
        <div className="loading-more">
          <FaSpinner className="spinner" />
          <p>Loading more products...</p>
        </div>
      )}
    </div>
  );
};

export default Products;
