// src/services/backend.js
//
// Talks to the Express backend (see the separate `backend/` project —
// `server.js`, run with `npm start`, defaults to http://localhost:5000).
// Set REACT_APP_API_URL in a `.env` file to point at a different host
// (e.g. a deployed backend) without touching this file.

import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// The backend returns each product's images as full URLs already
// (see server.js), so we just add a couple of fields the UI expects:
// `name` (alias of `title`) and `image` (a flat cover image).
const normalize = (product) => ({
  ...product,
  name: product.title,
  image: product.colors?.[0]?.images?.[0] || null,
});

// Fetches the full catalog once and caches it in memory for the life of the
// tab. All the helpers below read from this single cached list, so opening
// several pages doesn't re-fetch the catalog over and over.
let cache = null;
let inflight = null;

const loadAll = () => {
  if (cache) return Promise.resolve(cache);
  if (!inflight) {
    inflight = axios
      .get(`${API_BASE}/api/products`)
      .then((res) => {
        cache = res.data.map(normalize);
        return cache;
      })
      .finally(() => {
        inflight = null;
      });
  }
  return inflight;
};

// Clears the cache — call this if you add an "admin" flow that changes
// products and want the storefront to pick up the change without a reload.
export const invalidateProductCache = () => {
  cache = null;
};

export const getAllProducts = () => loadAll();

export const getCategories = async () => {
  const all = await loadAll();
  return [...new Set(all.map((p) => p.category))];
};

export const getProducts = async ({ search = '', category = 'All', page = 1, limit = 12 } = {}) => {
  let list = await loadAll();

  if (category && category !== 'All') {
    list = list.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }
  if (search) {
    const q = search.toLowerCase();
    list = list.filter(
      (p) => p.title.toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)
    );
  }

  const start = (page - 1) * limit;
  const pageItems = list.slice(start, start + limit);

  return {
    items: pageItems,
    total: list.length,
    hasMore: start + limit < list.length,
  };
};

export const getProductById = async (id) => {
  const all = await loadAll();
  return all.find((p) => p.id === Number(id)) || null;
};
