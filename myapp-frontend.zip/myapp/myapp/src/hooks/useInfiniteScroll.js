import { useState, useEffect, useRef, useCallback } from 'react';

export const useInfiniteScroll = (fetchMore, options = {}) => {
  const [isFetching, setIsFetching] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const observer = useRef();
  const loadingRef = useRef(false);

  const lastElementRef = useCallback(
    (node) => {
      if (loadingRef.current) return;
      if (observer.current) observer.current.disconnect();
      
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore && !isFetching) {
          loadingRef.current = true;
          setIsFetching(true);
          fetchMore()
            .then((hasMoreData) => {
              setHasMore(hasMoreData);
              setIsFetching(false);
              loadingRef.current = false;
            })
            .catch(() => {
              setIsFetching(false);
              loadingRef.current = false;
            });
        }
      }, options);

      if (node) observer.current.observe(node);
    },
    [fetchMore, hasMore, isFetching, options]
  );

  return { lastElementRef, isFetching, hasMore };
};
