// src/hooks/useAllProducts.js
import { useQuery } from '@tanstack/react-query';
import { fetchAllProducts } from '../utils/api';

// Shared cache for "give me the whole catalog" — used by Home, Collections,
// CollectionPage, and Wishlist so they don't each re-fetch it.
export const useAllProducts = () =>
  useQuery({
    queryKey: ['allProducts'],
    queryFn: fetchAllProducts,
    staleTime: 5 * 60 * 1000,
  });
