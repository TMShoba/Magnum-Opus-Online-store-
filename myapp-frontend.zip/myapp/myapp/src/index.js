import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// All providers (Auth, Theme, Cart, Wishlist, Query) are set up once, inside
// App.js. Wrapping them again here was creating a second, disconnected copy
// of each context.
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
