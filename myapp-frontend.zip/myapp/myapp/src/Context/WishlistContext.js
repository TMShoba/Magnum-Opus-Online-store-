import React, { createContext, useContext, useCallback, useMemo } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const WishlistContext = createContext();

const WISHLIST_STORAGE_KEY = 'wishlist_items';

export const WishlistProvider = ({ children }) => {
  const [wishlistItems, setWishlistItems] = useLocalStorage(WISHLIST_STORAGE_KEY, []);

  // Add a product to the wishlist if it's not already there
  const addToWishlist = useCallback((product) => {
    setWishlistItems((prev) => {
      const exists = prev.some((item) => item.id === product.id);
      return exists ? prev : [...prev, product];
    });
  }, [setWishlistItems]);

  // Remove a product from the wishlist by ID
  const removeFromWishlist = useCallback((id) => {
    setWishlistItems((prev) => prev.filter((item) => item.id !== id));
  }, [setWishlistItems]);

  // Check if a product is in the wishlist
  const isInWishlist = useCallback((id) => {
    return wishlistItems.some((item) => item.id === id);
  }, [wishlistItems]);

  // Toggle a product in the wishlist (add if not present, remove if present)
  const toggleWishlistItem = useCallback((product) => {
    setWishlistItems((prev) => {
      const exists = prev.some((item) => item.id === product.id);
      return exists 
        ? prev.filter((item) => item.id !== product.id)
        : [...prev, product];
    });
  }, [setWishlistItems]);

  // Clear the entire wishlist
  const clearWishlist = useCallback(() => {
    setWishlistItems([]);
  }, [setWishlistItems]);

  // Get the number of items in the wishlist
  const itemCount = useMemo(() => wishlistItems.length, [wishlistItems]);

  const value = useMemo(() => ({
    wishlistItems,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    toggleWishlistItem,
    clearWishlist,
    itemCount,
  }), [
    wishlistItems,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    toggleWishlistItem,
    clearWishlist,
    itemCount,
  ]);

  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
