// src/Context/CartContext.js
import React, { createContext, useContext, useCallback, useMemo } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const CartContext = createContext();

const CART_STORAGE_KEY = 'cart_items';

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useLocalStorage(CART_STORAGE_KEY, []);

  // Add a product to the cart, or update the quantity if it's already in the cart
  const addToCart = useCallback((product, quantity = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [...prev, { ...product, quantity }];
      }
    });
  }, [setCartItems]);

  // Remove a product from the cart by its ID
  const removeFromCart = useCallback((id) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  }, [setCartItems]);

  // Update the quantity of a product in the cart
  const updateQuantity = useCallback((id, quantity) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(1, quantity) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  }, [setCartItems]);

  // Increase the quantity of a product in the cart
  const increaseQuantity = useCallback((id, amount = 1) => {
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity + amount } : item
      )
    );
  }, [setCartItems]);

  // Decrease the quantity of a product in the cart
  const decreaseQuantity = useCallback((id, amount = 1) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.id === id
            ? { ...item, quantity: Math.max(1, item.quantity - amount) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }, [setCartItems]);

  // Clear the entire cart
  const clearCart = useCallback(() => {
    setCartItems([]);
  }, [setCartItems]);

  // Calculate the total amount for the cart
  const totalAmount = useMemo(() => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  }, [cartItems]);

  // Calculate the total number of items in the cart
  const itemCount = useMemo(() => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  }, [cartItems]);

  // Check if a product is in the cart
  const isInCart = useCallback((id) => {
    return cartItems.some((item) => item.id === id);
  }, [cartItems]);

  const value = useMemo(() => ({
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    increaseQuantity,
    decreaseQuantity,
    clearCart,
    totalAmount,
    itemCount,
    isInCart,
  }), [
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    increaseQuantity,
    decreaseQuantity,
    clearCart,
    totalAmount,
    itemCount,
    isInCart,
  ]);

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
