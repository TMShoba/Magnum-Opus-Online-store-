import React, { useEffect, useState, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { ErrorBoundary } from 'react-error-boundary';
import { ToastContainer } from 'react-toastify';
import AOS from 'aos';

// External CSS (alphabetical order)
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'aos/dist/aos.css';
import 'react-toastify/dist/ReactToastify.css';
import './fonts.css'; // Import custom fonts
import './styles/theme.css';
import './App.css';

// Context Providers
import { AuthProvider, useAuth } from './Context/AuthContext';
import { CartProvider } from './Context/CartContext';
import { queryClient } from './providers/QueryProvider';
import { ThemeProvider, useTheme } from './Context/ThemeContext';
import { WishlistProvider } from './Context/WishlistContext';

// Components
import CartSideBar from './Components/CartSideBar';
import ErrorFallback from './Components/common/ErrorFallback';
import LoadingSpinner from './Components/common/LoadingSpinner';
import NavBar from './Components/NavBar';

// Lazy-loaded pages (alphabetical order)
const About = lazy(() => import('./Pages/About'));
const CartPage = lazy(() => import('./Pages/CartPage'));
const Checkout = lazy(() => import('./Pages/Checkout'));
const CollectionPage = lazy(() => import('./Pages/CollectionPage'));
const Home = lazy(() => import('./Pages/Home'));
const LoginPage = lazy(() => import('./Pages/LoginPage'));
const ProductDetail = lazy(() => import('./Pages/ProductDetail'));
const Products = lazy(() => import('./Pages/Products'));
const SignupPage = lazy(() => import('./Pages/SignupPage'));
const WishlistPage = lazy(() => import('./Pages/Wishlist'));

// Protected route component for React Router v6
const ProtectedRoute = ({ children, requiredRoles = [] }) => {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    // Redirect to login with the current location to redirect back after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (requiredRoles.length > 0 && !requiredRoles.includes(user?.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
};

// Main App component
const AppContent = () => {
  const { darkMode } = useTheme();
  const [isCartOpen, setCartOpen] = useState(false);

  const toggleCart = () => setCartOpen(prev => !prev);

  useEffect(() => {
    AOS.init({ 
      duration: 800, 
      once: true,
      offset: 50,
      easing: 'ease-in-out',
    });
  }, []);

  return (
    <div className={`app ${darkMode ? 'dark' : ''}`}>
      <Router>
        <ErrorBoundary FallbackComponent={ErrorFallback}>
          <NavBar onCartOpen={toggleCart} />
          <CartSideBar isOpen={isCartOpen} onClose={toggleCart} />
          
          <Suspense fallback={<LoadingSpinner fullPage />}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/products" element={<Products />} />
              <Route path="/products/:id" element={<ProductDetail />} />
              <Route path="/collections/:id" element={<CollectionPage />} />
              
              {/* Protected Routes */}
              <Route 
                path="/cart" 
                element={
                  <ProtectedRoute>
                    <CartPage />
                  </ProtectedRoute>
                } 
              />
              
              <Route 
                path="/checkout" 
                element={
                  <ProtectedRoute>
                    <Checkout />
                  </ProtectedRoute>
                } 
              />
              
              <Route 
                path="/wishlist" 
                element={
                  <ProtectedRoute>
                    <WishlistPage />
                  </ProtectedRoute>
                } 
              />
              
              {/* Auth Routes */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              
              {/* 404 Route */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
          
          <ToastContainer 
            position="bottom-right"
            autoClose={5000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme={darkMode ? 'dark' : 'light'}
          />
          
          {process.env.NODE_ENV === 'development' && (
            <ReactQueryDevtools initialIsOpen={false} />
          )}
        </ErrorBoundary>
      </Router>
    </div>
  );
};

// App wrapper with all providers
const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ThemeProvider>
        <CartProvider>
          <WishlistProvider>
            <AppContent />
          </WishlistProvider>
        </CartProvider>
      </ThemeProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
